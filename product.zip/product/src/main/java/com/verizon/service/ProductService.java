package com.verizon.service;

import com.verizon.exception.ProductNotFoundException;
import com.verizon.model.Product;
import com.verizon.repository.ProductDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    @Autowired
    private ProductDao productDao;

    public void addProduct(Product product) {
        productDao.save(product);
    }

    public List<Product> getAllProducts() {
        return productDao.findAll();
    }

    public Product getProductById(Integer id) throws ProductNotFoundException {
        return productDao.findById(id).orElseThrow(() -> new ProductNotFoundException("Product not found"));
    }

    public List<Product> getAllProductsBetweenPrice(Integer low, Integer high) {
        return productDao.findByPriceBetween(low, high);
    }

    public void updateProduct(Integer id, Product product) throws ProductNotFoundException {
        if (!productDao.existsById(id)) {
            throw new ProductNotFoundException("Product not found");
        }
        product.setId(id);
        productDao.save(product);
    }

    public void deleteProduct(Integer id) throws ProductNotFoundException {
        if (!productDao.existsById(id)) {
            throw new ProductNotFoundException("Product not found");
        }
        productDao.deleteById(id);
    }
}
